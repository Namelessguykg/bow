// document.addEventListener('DOMContentLoaded', () => {
//     const cartItemsContainer = document.getElementById('cart-items');
//     const subtotalPriceEl = document.getElementById('subtotal-price');
//     const shippingPriceEl = document.getElementById('shipping-price');
//     const finalTotalEl = document.getElementById('final-total');
//     const applyCouponBtn = document.getElementById('apply-coupon-btn');
//     const couponInput = document.getElementById('coupon-input');

//     let discountRate = 0;

//     function updateCartTotals() {
//         let subtotal = 0;
//         const rows = cartItemsContainer.querySelectorAll('tr');

//         rows.forEach(row => {
//             const price = parseFloat(row.getAttribute('data-price'));
//             const qtyInput = row.querySelector('.qty-input');
//             const totalCell = row.querySelector('.total');

//             let qty = parseInt(qtyInput.value);
//             if (isNaN(qty) || qty < 1) {
//                 qty = 1;
//                 qtyInput.value = 1;
//             }

//             const rowTotal = price * qty;
//             totalCell.textContent = `$${rowTotal.toFixed(2)}`;
//             subtotal += rowTotal;
//         });

//         // Shipping cost rule: if cart is empty, shipping is 0, else 10
//         let shippingCost = subtotal > 0 ? 10.00 : 0.00;

//         // Apply coupon discount
//         let discountedSubtotal = subtotal - (subtotal * discountRate);
//         let finalTotal = discountedSubtotal + shippingCost;

//         // Update UI Text
//         subtotalPriceEl.textContent = `$${subtotal.toFixed(2)}`;
//         shippingPriceEl.textContent = `$${shippingCost.toFixed(2)}`;
//         finalTotalEl.textContent = `$${finalTotal.toFixed(2)}`;
//     }

//     // Listen to quantity change
//     cartItemsContainer.addEventListener('input', (e) => {
//         if (e.target.classList.contains('qty-input')) {
//             updateCartTotals();
//         }
//     });

//     // Listen to delete row
//     cartItemsContainer.addEventListener('click', (e) => {
//         if (e.target.closest('.delete-btn')) {
//             const row = e.target.closest('tr');
//             row.remove();
//             updateCartTotals();
//         }
//     });

//     // Coupon logic
//     if (applyCouponBtn) {
//         applyCouponBtn.addEventListener('click', () => {
//             const code = couponInput.value.trim().toUpperCase();
//             if (code === 'SAVE10') {
//                 discountRate = 0.10;
//                 alert('Coupon applied successfully! 10% discount added.');
//                 updateCartTotals();
//             } else if (code === '') {
//                 alert('Please enter a coupon code.');
//             } else {
//                 alert('Invalid coupon code!');
//             }
//         });
//     }

//     // Run initial total calculation on load
//     updateCartTotals();
// });